package com.viettel.vocs.pcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcfApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcfApplication.class, args);
	}

}
