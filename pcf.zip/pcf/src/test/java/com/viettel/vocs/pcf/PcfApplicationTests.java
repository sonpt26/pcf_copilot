package com.viettel.vocs.pcf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcfApplicationTests {

	@Test
	void contextLoads() {
	}

}
